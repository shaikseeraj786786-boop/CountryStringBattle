# Country String Battle — Android Studio Project

A complete, production-grade Android native WebView game app based on Country String Battle.

## Key Features
- **100% Offline Ready**: The entire HTML5 game with all 20 country flags, synth sfx, and meme pride cards is packaged into the local `app/src/main/assets/game/` folder.
- **Hardware Accelerated**: Configured in AndroidManifest.xml and WebView for smooth 60fps animations on mobile.
- **Immersive Sticky Fullscreen**: Hides the status bar and bottom navigation pills automatically on Android 7.0 through Android 14.
- **Native Haptics**: Uses the native Android `Vibrator` / `VibratorManager` via `WebAppInterface` for tactile response during snaps and ball explosions.
- **Custom App Icon & Splash Screen**: Includes custom vector insignia and an animated launch screen.

---

## How to Build the APK in Android Studio

### Prerequisites
1. Download and install [Android Studio](https://developer.android.com/studio) (Hedgehog, Iguana, or later).
2. Ensure you have **Android SDK 34** and **JDK 17** installed (configured automatically in Android Studio).

### Step 1: Open the Project
1. Extract the downloaded `CountryStringBattle-Android-Project.zip` to a folder on your computer.
2. Open Android Studio, click **File > Open**, and select the extracted folder.
3. Wait for Android Studio to sync Gradle (usually takes 30-60 seconds on first run).

### Step 2: Test on Emulator or Phone
1. Connect your Android phone via USB and enable **USB Debugging** (or start an Android Virtual Device from Device Manager).
2. Select your device from the toolbar dropdown.
3. Click the green **Run (▶)** button or press `Shift + F10`.

### Step 3: Generate the APK File
1. In the top menu, go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
2. Once the build completes, Android Studio will show a notification popup in the bottom right:
   * Click **locate** to open the folder containing `app-debug.apk`.
   * File path: `app/build/outputs/apk/debug/app-debug.apk`.

### Step 4: Install APK to Your Phone
- You can transfer `app-debug.apk` via USB cable, WhatsApp, or Google Drive directly to your Android device and tap to install!
- Or from terminal:
  ```bash
  adb install app/build/outputs/apk/debug/app-debug.apk
  ```

---

## CLI Build (Without Android Studio GUI)
If you have the Android SDK installed on your system, you can build from the command line:
```bash
# On Linux / macOS:
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
```
The generated APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
